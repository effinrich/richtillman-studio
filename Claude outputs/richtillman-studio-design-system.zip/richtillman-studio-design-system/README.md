# Rich Tillman Studio — design system drop (2026-09-21)

brand/                 Brace mark set: rt-mark.svg (tile), rt-mark-notile.svg, rt-mark-mono.svg,
                       rt-wordmark.svg, rt-lockup.svg, rt-mark-{512,192,64,32,16}.png, brand-sheet.png
                       -> already written to apps/web/public/brand/
packages-ui-src/       BrandMark component + story, updated index.ts, navigation-bar.tsx, site-footer.tsx,
                       styles/app.css (+ --color-success, --color-success-foreground), composites/contact-success.tsx
                       -> already written to packages/ui/src/
design-system/         The Design System artifact's files: tokens.json, README.md (brand book),
                       components/* (41 guidelines + live previews, bundle.js/css, index.d.ts), assets/Logos/README.md
                       (the Logos images live in the artifact's asset store; use brand/ for the files)
apps-web/              favicon.ico (16/32/64 from the mark), manifest.json (brand icons, black theme),
                       src/routes/__root.tsx (icon/apple-touch-icon/manifest links, theme-color)
                       -> already written to apps/web/; logo192/512.png overwritten with the mark
