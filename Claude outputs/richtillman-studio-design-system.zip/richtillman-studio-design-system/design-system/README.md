The system `richtillman.xyz` ships: one dark OLED theme, gold as the only action color, glass surfaces, Inter for reading and JetBrains Mono for meta. Source of truth is `@richtillman/ui` (`packages/ui/src`); the site's `/design-system` route renders those same modules. Build on it as a consuming agent would: name the tokens, use the components as specified, add nothing the source doesn't have.

## Content fundamentals

- Voice is first person, direct, engineering-literate. Real copy: "Building the bridge." · "Frontend & AI-native tooling." · "The system this site actually ships." · "If a recipe needed a class string, it is a component now."
- Sentence case for headings and body. Eyebrows, Labels and Badges are UPPERCASE via CSS, never typed in caps.
- Metrics are terse numerals with a unit or plus sign: "6,200+".
- No emoji anywhere. Icons are Lucide glyphs (`lucide-react`), 16px inside Buttons (`h-4 w-4`), 12px in link Buttons (`h-3 w-3`), always `aria-hidden`.
- Button labels are verbs or destinations: "See selected work", "Get in touch", "Discuss a project", "Send message". A pending state reads "Sending...".
- Eyebrow text names the section: "Selected Work", "Design System", "Foundations", "Primitives", "Composites".

## Color

- The ground is always `color-background` (#000000). There is one theme; `color-scheme: dark` is set on `html`. Do not introduce a light theme or zinc greys.
- `color-gold` is the only primary action color. One gold CTA per view. Gold also carries eyebrows, the section rule (`bg-gold/40`, 48px × 1px), the availability dot, neon text, and the focus ring.
- `color-cyan` and `color-magenta` are accents for Badges and neon rails. They never separate two things on their own — pair with a label.
- Text on black: `color-foreground` for headings and control text; `color-muted-foreground` (white 50%) for descriptions, Labels, Tags, placeholders, inactive tabs — 5.3:1, the floor. `text-white/70` (Badge neutral, default Chip) and `/60` (body lead) sit between. Never go below 50% for readable text; `white/40` and `white/10` are for rules and borders only.
- Glass: `color-glass` fill + 16px `backdrop-filter: blur` + 1px `color-border-glass` + `shadow-glass`. That is `.glass-panel`. Text on glass keeps the same tokens (black shows through at 60%, contrast holds: white/50 on glass 4.6:1).
- Inputs: `color-input` (black 40%) + 8px blur + `color-border-glass`. Hover border white 15%; focus border gold 50%, `shadow-input-focus`, fill black 50%.
- `color-destructive` (#f87171) only for Field error text with `role="alert"` and `aria-invalid` on the control. `color-success` (#4ade80) and `color-success-foreground` (#86efac) only for the ContactSuccess banner.
- Tints are alpha over black, not separate hex: gold/10 fill + gold/30 border (gold Badge, outline Button border), gold/5 fill (status Chip), white/5 + white/10 (neutral Badge), white/10 (Separator, tab border, Tag border).
- Hover gold is the literal `#ffe54c` (primary Button fill, ghost Button text). It is not a token; keep it only in those two places.

## Typography

- Families: `sans` = Inter (400, 500, 600, 700, 800), `mono` = JetBrains Mono (400, 500). Both load from Google Fonts (`@import` in app.css); no font files are committed.
- Display: `hero` (Inter 800, 48→96px responsive, `tracking-tighter`), `section` (Inter 700, 48→72px, tighter) for SectionHeader, `metric` (700, 36→48px, tight). Headings sit on `color-foreground`; a single word may take `.neon-text` (gold with an 18px gold text-shadow at 45%).
- Reading: `body-lg` (18→20px, `leading-relaxed` 1.625, `color-muted-foreground`, `max-w-2xl`) for leads and descriptions; `body` 16px for controls.
- Meta is always mono: `eyebrow` (12px, uppercase, 0.3em tracking, gold), `label` (12px, uppercase, 0.1em, muted), `badge` (10px, 700, uppercase, 0.2em), `tag` (10px, muted), `meta` (11px, muted).
- Responsive steps come from Tailwind breakpoints (`sm` 640, `md` 768, `lg` 1024); the token lists the largest size.

## Spacing, sizing, layout

- Tailwind v4 default scale (4px base); no custom steps. Controls use `px-6 py-3` (Button), `px-4 py-3` (inputs), `px-3 py-1` (Badge), `px-3 py-1.5` (Chip), `px-2 py-0.5` (Tag).
- Every interactive control is at least 44px tall (`min-h-11`); tab links are also `min-w-11`.
- Page container: `max-w-7xl`, `px-6`, `pt-32 pb-24`, below a fixed 80px header (`site-header-height`). In-page sub-nav is 56px (`ds-subnav-height`) and sticks at header − 1px; anchored sections use `scroll-mt` of 8.5rem.
- Section rhythm: `space-y-28` between DocsSections; SectionHeader carries `mb-16 md:mb-24`.
- GlassPanel content padding is `p-6 md:p-8`; specimen panels are `rounded-2xl`.

## Radii

- `--radius: 0.375rem` is declared for controls, with the source comment "not stadium pills". The primitives today render Tailwind `rounded` (0.25rem = `radius-sm`), `rounded-lg` (0.5rem) on ghost/muted Buttons, `rounded-2xl` (1rem) on panels, `rounded-full` on the Chip dot. When re-pointing controls to `radius`, change Button, Badge, Chip, Tag, Input, Textarea, Select together.

## Borders, shadows, effects

- Borders are 1px hairlines at white 8–10%; the only colored borders are gold/30 (outline Button, gold Badge, status Chip), cyan/30, magenta/30.
- Shadows are glows, not elevation: `shadow-gold-glow` on the primary Button (→ `shadow-gold-glow-hover`), `shadow-glass-hover` on the glass Button, `shadow-input-focus` on focused inputs, `shadow-glass` under every panel.
- Neon rails: `.neon-border-gold|cyan|magenta` = 4px solid left border + `shadow-rail-*` bloom. Use on a GlassPanel to mark one item among many; one rail color per group.
- Blur marks a raised or dismissed surface. It is not decoration. Status Chips in the fixed header skip `backdrop-filter` on purpose (compositing).

## States, focus, motion

- Focus: `focus-visible` only — 2px ring in `color-ring` at 60% with a 2px black offset (`ring-offset-black`). Never remove it; `.glass-input` replaces the outline with the gold border + `shadow-input-focus`.
- Disabled: `opacity-50`, `cursor-not-allowed`, `pointer-events-none`.
- Hover: primary Button lifts to `#ffe54c` and `scale-105` under `motion-safe`; glass Button fills white/10; outline fills gold/10; muted text goes white/50 → white.
- Transitions: `duration-control` 300ms on Buttons and inputs, `duration-tab` 200ms on tabs. Entrance: `.stagger-1..6` (`fade-in-up`, 600ms ease-out, 100ms steps). Looping: `.animate-ticker` 30s, `animate-pulse` on the availability dot. All of it is `animation: none` under `prefers-reduced-motion` and in Storybook (`.sb-show-main`).
- Route changes use a view transition: `page-sweep-in` 0.6s `ease-page-sweep`, a left-to-right clip wipe with a brightness flash.

## Iconography

- Lucide (`lucide-react` ^0.545), stroke icons, `aria-hidden` when decorative. Sizes 16px in Buttons, 12px in external-link Buttons. No icon font, no emoji.
- The brand mark lives in code as `BrandMark` (`packages/ui/src/brand-mark.tsx`) and as files under `apps/web/public/brand/`. `apps/web/public/logo*.png` and `favicon.ico` are still the default React template files — point the web manifest and favicon at `brand/rt-mark-*.png`.

## Logo

- The Logos group holds the mark, "Brace": JetBrains Mono `{ }` in `color-foreground` joined by a `color-gold` span with a `color-magenta` node — the bridge between design systems and code, in the system's own meta face. Use `rt-lockup.svg` in the header and footer, `rt-mark.svg` as the app icon (24px and up); rules in `assets/Logos/README.md`.
- Until the mark is adopted, the name in plain type remains valid: "Rich Tillman Studio" in the `section` style.

## Components

Forty-one components built from `packages/ui`, running live in their previews (React 18 globals, the package's own Tailwind stylesheet compiled to `components/bundle.css`, `lucide-react` 0.545 bundled in). Groups follow the repo's Storybook titles: Primitives, Forms, Surfaces, Page (`Primitives/*`), Cards (`Cards/*` — the composites), Layout (`Layout/*`), Screens (`Screens/*` — the 15 full pages, each inside `PortfolioLayout`, router-free: the app passes CTAs as `ReactNode` and data from Supabase or its seed). Each component's guideline names its props, its source file and which recipes it composes.

- Cards hold content models from `models.ts` (`ArticleCardModel`, `ProjectCardModel`, `SiteMapLinkModel`, `ColorToken`); the previews use the repo's `fixtures.ts` samples, exported on the bundle as `SAMPLE_ARTICLES`, `SAMPLE_PROJECTS`, `SAMPLE_SITE_MAP`.
- Layout is one shell: `PortfolioLayout` = CanvasBackground + NavigationBar + page + optional TechTicker + SiteFooter. CanvasBackground pulls `threejs-components` from jsDelivr at runtime and degrades to grid + scrim when it can't.
- The header and footer render `BrandMark` (the Brace mark as a component, 32px / 40px, ink `color-foreground`). No zinc remains in the system.
- Screens seed from `fixtures.ts` (`SAMPLE_*`, exported on the bundle); CaseStudyDetail also carries the app's `DETAIL_CONTENT` sections for the Nx study. TestimonialsScreen has no empty state and the app's seed list is empty — add one before real data.
- ContactSuccess uses `color-success` / `color-success-foreground`, the system's only green pair.

## Not synced

- Route taken: built. The `@richtillman/ui` primitives, composites and layout were bundled in a sandbox with esbuild (IIFE; `react`, `react-dom`, `react/jsx-runtime` resolved to `window.React`/`window.ReactDOM`; global `window.RichTillmanUI`), and `app.css` compiled with Tailwind v4.3 against the primitive sources and these previews. The source targets React 19; the previews run it on React 18.3 — the primitives use no 19-only API.
- Fonts: Inter and JetBrains Mono are Google-hosted; no files fetched (the wordmark SVG is outlined, so it needs none).
- Assets: the Logos group was drawn here and written back to `apps/web/public/brand/`; `BrandMark` is the in-code form.
- Tokens skipped: `--ds-scroll-margin` (calc), `--font-sans` / `--font-mono` (placed under `type.families`), the `.neon-text` text-shadow (prose only), scrollbar styles.
- Components not built: none — 41 of 41 exports carry a live preview.
- Commit sha not recorded (synced from the local checkout on branch `main`).
