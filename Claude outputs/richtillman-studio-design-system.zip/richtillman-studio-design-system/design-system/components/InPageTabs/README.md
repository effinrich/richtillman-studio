# InPageTabs
Sticky anchor sub-navigation that highlights the section in view. Built from `packages/ui/src/in-page-tabs.tsx`; the preview runs the real component (IntersectionObserver + `hashchange`).

**Use it** on long documentation-style pages (Design System, Resume) with 3–6 anchored sections whose ids match the hrefs and carry `scroll-mt-[var(--ds-scroll-margin)]`.

**You provide:** `items` (`{ href: "#id", label }[]`), optional `ariaLabel` (default "On this page").

**Tokens:** sticks at `site-header-height` − 1px; row height `ds-subnav-height`; bottom border white/10; link = `small` 500 with 0.025em tracking, `color-muted-foreground` → hover white/80 → current `color-foreground` with a 2px `color-gold` bottom border; padding `space-3`; min size `space-11`; transition `duration-tab`; focus `color-ring`.

**Do:** keep labels one word. **Don't:** use for routing between pages — this is anchors only.
