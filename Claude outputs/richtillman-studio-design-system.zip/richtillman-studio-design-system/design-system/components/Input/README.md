# Input
Glass text input: black at 40% with an 8px blur, hairline border, gold focus. Built from `packages/ui/src/input.tsx`; the preview runs the real component.

**Use it** for single-line text, email, URL inside a `Field`.

**You provide:** `id` (required for error wiring), `name`, `type`, `placeholder`, `autoComplete`, `error` (same string as the Field's), native input attributes.

**Tokens:** `.glass-input` — fill `color-input`, border `color-border-glass`, hover border white/15, focus border gold/50 + `shadow-input-focus` + fill black/50; text `color-foreground`; placeholder `color-muted-foreground`; min height `space-11`; padding `space-3` × `space-4`; radius `radius-sm`; transition `duration-control`.

**Do:** always give it an `id` and a Label. Set `autoComplete`.
**Don't:** style the error state with a red border — the source uses the message and `aria-invalid` only.
