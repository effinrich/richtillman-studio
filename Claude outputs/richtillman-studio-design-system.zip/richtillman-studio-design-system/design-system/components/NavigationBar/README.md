# NavigationBar
Fixed 80px header: BrandMark + name/title, primary links (Work, Stack, Design System, Resume, Contact), status Chip, and a mobile menu button below 768px with an Escape-closing overlay. Built from `packages/ui/src/layout/navigation-bar.tsx` + `layout/nav.ts`.

**Use it** through PortfolioLayout; standalone only for a custom shell. Links are plain anchors to `PRIMARY_NAV` hrefs.

**You provide:** `activeItem?: NavItem` (default "home"; highlights the matching link white) and `isAvailable?: boolean` (default true; shows the status Chip).

**Tokens:** height `site-header-height`; solid `color-background` with an inset white/5 highlight and a white/10 bottom hairline — deliberately NO backdrop blur (Chromium compositing bug with `overflow-x: hidden`); links 14px 500 `text-white/60` → white, `min-h-11`; menu button `min-h-11 min-w-11` `radius-lg` border white/10; overlay black/60. The mark is `BrandMark` at 32px in `color-foreground`; the anchor carries `aria-label="Rich Tillman Studio — home"` because the name is hidden below `sm`.

**Do:** pass the current route's `NavItem` so the link reads current. **Don't:** add a sixth primary link; secondary routes belong in the footer.
