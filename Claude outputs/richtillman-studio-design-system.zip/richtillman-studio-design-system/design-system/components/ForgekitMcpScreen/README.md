# ForgekitMcpScreen
The ForgeKit MCP project page: back link, Badges, title, description, a package grid (forgekit-figma-mcp, forgekit-storybook-mcp, CLI), install snippets in mono, and external links. Content is hard-coded in the component. Built from `packages/ui/src/screens/forgekit-mcp-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** optional `backHref` (default `/work`). Nothing else — edit the source to change copy.

**Tokens:** code blocks `text-sm font-mono` on `bg-black/40` with `color-border-glass`; Badges gold/cyan/magenta for the three package roles; ExternalLink icons 16px. `activeItem="work"`.
