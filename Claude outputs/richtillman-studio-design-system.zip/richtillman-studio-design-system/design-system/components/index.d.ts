// Types as documentation — transcribed from packages/ui/src (@richtillman/ui).
// Source components are React 19 function components styled with Tailwind v4 utilities;
// `className` is merged through `cn` (clsx + tailwind-merge).

import type {
  AnchorHTMLAttributes,
  ButtonHTMLAttributes,
  ComponentProps,
  HTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  SVGProps,
} from "react"

/** Merges class lists with clsx + tailwind-merge. */
export function cn(...inputs: Array<string | false | null | undefined | Record<string, boolean>>): string

// ---------------------------------------------------------------- Button
export type ButtonVariant = "primary" | "gold" | "glass" | "outline" | "ghost" | "muted"

export type ButtonStyleProps = {
  /** `primary` and `gold` are the same gold CTA. Default "primary". */
  variant?: ButtonVariant | null
  /** `w-full sm:w-auto` — full width on phones only. Default false. */
  fullWidth?: boolean | null
}

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  ButtonStyleProps & {
    /** Render the child element (Radix Slot) instead of a <button>; `type` is then omitted. */
    asChild?: boolean
  }

/** Gold CTA and its variants. Defaults: type="button", variant="primary". */
export function Button(props: ButtonProps): ReactNode

export type ButtonAnchorProps = AnchorHTMLAttributes<HTMLAnchorElement> & ButtonStyleProps

/** Anchor with Button styling; default variant "muted". The app wraps it with TanStack `createLink` as ButtonLink. */
export const ButtonAnchor: React.ForwardRefExoticComponent<ButtonAnchorProps & React.RefAttributes<HTMLAnchorElement>>

/** Returns the class string for a variant without rendering. */
export function buttonClassName(props: ButtonStyleProps & { className?: string }): string

// ---------------------------------------------------------------- BrandMark
export type BrandMarkProps = Omit<SVGProps<SVGSVGElement>, "children"> & {
  /** Draw the black rounded tile behind the mark (app-icon form). Default false. */
  tile?: boolean
}
/** The Brace mark: braces in currentColor, gold span, magenta node. aria-hidden by default. */
export function BrandMark(props: BrandMarkProps): ReactNode

// ---------------------------------------------------------------- Badge
export type BadgeVariant = "gold" | "cyan" | "magenta" | "neutral"

export type BadgeProps = {
  children: ReactNode
  /** Default "neutral". */
  variant?: BadgeVariant
  className?: string
}

/** Mono, uppercase, 0.2em-tracked pill for categories ("Featured", "AI Engineering"). */
export function Badge(props: BadgeProps): ReactNode

// ---------------------------------------------------------------- Chip
export type ChipVariant = "default" | "status"

export type ChipProps = HTMLAttributes<HTMLSpanElement> & {
  children: ReactNode
  /** "default" = glass panel, mono, white/70. "status" = gold outline, no blur (lives in the fixed header). */
  variant?: ChipVariant
  /** Leading gold dot (6px; 8px on status). */
  dot?: boolean
  /** Pulse the dot; off under prefers-reduced-motion. */
  pulse?: boolean
}

/** 44px-tall glass or status chip: stack items, availability. */
export function Chip(props: ChipProps): ReactNode

// ---------------------------------------------------------------- Tag
export type TagProps = HTMLAttributes<HTMLSpanElement> & { children: ReactNode }

/** Smallest label: 10px mono, hairline border, white/50. Tech names on cards. */
export function Tag(props: TagProps): ReactNode

// ---------------------------------------------------------------- Field family
export type FieldProps = {
  label: string
  /** Must equal the control's `id`; the error paragraph is `${htmlFor}-error`. */
  htmlFor: string
  /** Rendered below the control in `color-destructive` with role="alert". Pass the same string to the control. */
  error?: string
  children: ReactNode
}

/** Label + control + error wrapper. Wires ids; the control wires aria. */
export function Field(props: FieldProps): ReactNode

export type InputProps = ComponentProps<"input"> & {
  /** Sets aria-invalid and aria-describedby=`${id}-error`. */
  error?: string
}
/** Glass text input, 44px min height. */
export function Input(props: InputProps): ReactNode

export type TextareaProps = ComponentProps<"textarea"> & { error?: string }
/** Glass textarea, resize disabled. */
export function Textarea(props: TextareaProps): ReactNode

export type SelectProps = SelectHTMLAttributes<HTMLSelectElement> & { error?: string }
/** Glass native select; pass <option> children. */
export function Select(props: SelectProps): ReactNode

// ---------------------------------------------------------------- Label
export type LabelProps = ComponentProps<"label">
/** Mono uppercase form label, white/50, 8px bottom margin. */
export function Label(props: LabelProps): ReactNode

// ---------------------------------------------------------------- Separator
export type SeparatorProps = {
  className?: string
  /** Default "horizontal" renders <hr>; "vertical" renders an aria-hidden 1px div. */
  orientation?: "horizontal" | "vertical"
}
export function Separator(props: SeparatorProps): ReactNode

// ---------------------------------------------------------------- GlassPanel
export type GlassPanelProps = { children: ReactNode; className?: string }
/** `.glass-panel` div. Caller supplies radius and padding (`rounded-2xl p-6 md:p-8`). */
export function GlassPanel(props: GlassPanelProps): ReactNode

// ---------------------------------------------------------------- SectionHeader
export type SectionHeaderProps = {
  /** Mono gold eyebrow after a 48px gold rule. */
  eyebrow?: string
  /** May contain a `<span className="neon-text">` word. */
  title: ReactNode
  description?: string
  className?: string
  /** Default "h1"; use "h2" inside a page that already has an h1. */
  headingLevel?: "h1" | "h2"
}
export function SectionHeader(props: SectionHeaderProps): ReactNode

// ---------------------------------------------------------------- InPageTabs
export type InPageTab = { href: `#${string}`; label: string }

export type InPageTabsProps = {
  items: readonly InPageTab[]
  /** Default "On this page". */
  ariaLabel?: string
}
/** Sticky anchor sub-nav; tracks the visible section with IntersectionObserver and `aria-current="location"`. */
export function InPageTabs(props: InPageTabsProps): ReactNode

// ================================================================ Composites (packages/ui/src/composites)
export type ArticleCardModel = { slug: string; title: string; excerpt: string; category: string; publishedAt: string; readTime: string; href: string; featured?: boolean; content?: string[] }
export type ProjectCardModel = { slug: string; title: string; description: string; tags: string[]; href: string; metric?: string; image?: string }
export type SiteMapAccent = "gold" | "cyan" | "magenta"
export type SiteMapLinkModel = { title: string; description: string; href: string; accent: SiteMapAccent }
export type ColorToken = { name: string; cssVar: string; value: string; usage: string }
export type ContactSubmitInput = { name: string; email: string; company?: string; projectType: string; message: string }
export type ContactSubmitHandler = (input: ContactSubmitInput) => Promise<unknown>

/** Glass link card for an Insights article. */
export function ArticleCard(props: { article: ArticleCardModel }): ReactNode
/** Portfolio card; kind (Project / Case Study / Article) derives from `href`. */
export function ProjectCard(props: { project: ProjectCardModel }): ReactNode
/** Accent-hover link card for the Site Map page. */
export function SiteMapCard(props: { link: SiteMapLinkModel }): ReactNode
/** Click-to-copy color swatch. */
export function TokenSwatch(props: { token: ColorToken }): ReactNode
/** Contact form with blur/submit validation; project types are fixed inside. */
export function ContactForm(props: { onSubmit: ContactSubmitHandler; onSubmitted?: () => void }): ReactNode
/** Email / location / availability panels. No props. */
export function ContactInfo(): ReactNode
/** Green "Message sent!" banner. No props. */
export function ContactSuccess(): ReactNode

export function isValidEmail(email: string): boolean
export function isNonEmpty(value: string): boolean
export function validateField(fieldName: string, value: string): Record<string, string>
export function getFieldErrors(formData: Record<string, string>): Record<string, string>

// ================================================================ Layout (packages/ui/src/layout)
export type NavItem = "home" | "work" | "stack" | "contact" | "insights" | "services" | "testimonials" | "resources" | "case-studies" | "faq" | "resume" | "design-system"
export type NavLink = { label: string; href: string; item: NavItem }
/** Work, Stack, Design System, Resume, Contact. */
export const PRIMARY_NAV: NavLink[]
/** Insights, Services, Case Studies, Testimonials, FAQ, Resume, Site Map. */
export const SECONDARY_NAV: NavLink[]

export type CanvasIntensity = "ambient" | "recessed"
/** Fixed backdrop: grid, scrim, WebGL tubes cursor (loaded from jsDelivr at runtime; off under reduced motion). */
export function CanvasBackground(props: { className?: string; intensity?: CanvasIntensity }): ReactNode
/** Fixed 80px header with primary links, status Chip and a mobile menu. */
export function NavigationBar(props: { activeItem?: NavItem; isAvailable?: boolean }): ReactNode
/** Canvas + nav + children + optional ticker + footer. */
export function PortfolioLayout(props: { children: ReactNode; activeItem?: NavItem; showTicker?: boolean }): ReactNode
/** Three-column footer. No props. */
export function SiteFooter(): ReactNode
/** Stack-name marquee. No props. */
export function TechTicker(): ReactNode

// ================================================================ Screens (packages/ui/src/screens)
export type Metric = { value: string; label: string }
export type CaseStudyModel = { slug: string; title: string; subtitle: string; tags: string[]; summary: string; metrics: { label: string; value: string }[]; href: string; image?: string; liveHref?: string }
export type CaseStudySection = { label: string; body: string }
export type FaqItemModel = { id: string; question: string; answer: string }
export type ResourceModel = { id: string; title: string; description: string; category: string; href: string }
export type ServiceModel = { id: string; title: string; description: string; icon: string }
export type TestimonialModel = { id: string; quote: string; author: string; role: string; company: string }
export type ResumeModel = { summary: string; experience: Array<{ title: string; company: string; period: string; highlights: string[] }>; projects: Array<{ title: string; detail: string }>; skills: string[] }
export type SiteMapSectionModel = { id: string; label: string; accent: SiteMapAccent; links: Omit<SiteMapLinkModel, "accent">[] }

/** Landing page inside PortfolioLayout (ticker on). `actions` = the two hero CTAs. */
export function HomeScreen(props: { metrics: readonly Metric[]; actions: ReactNode }): ReactNode
export function WorkScreen(props: { projects: ProjectCardModel[]; discussCta: ReactNode }): ReactNode
export function InsightsScreen(props: { articles: ArticleCardModel[]; featuredCta: ReactNode }): ReactNode
export function ArticleDetailScreen(props: { article: ArticleCardModel; backHref?: string }): ReactNode
export function CaseStudiesScreen(props: { caseStudies: CaseStudyModel[]; renderCta: (study: CaseStudyModel) => ReactNode }): ReactNode
export function CaseStudyDetailScreen(props: { caseStudy: CaseStudyModel; sections: CaseStudySection[]; related: CaseStudyModel[]; backHref?: string }): ReactNode
/** Hard-coded ForgeKit MCP project page. */
export function ForgekitMcpScreen(props: { backHref?: string }): ReactNode
export function ServicesScreen(props: { services: ServiceModel[] }): ReactNode
export function TestimonialsScreen(props: { testimonials: TestimonialModel[] }): ReactNode
export function ResourcesScreen(props: { resources: ResourceModel[] }): ReactNode
export function FaqScreen(props: { items: FaqItemModel[] }): ReactNode
export function ResumeScreen(props: { resume: ResumeModel; pdfHref?: string }): ReactNode
export function ContactScreen(props: { onSubmit: ContactSubmitHandler }): ReactNode
export function SiteMapScreen(props: { sections: SiteMapSectionModel[] }): ReactNode
export function DesignSystemScreen(props: { specimenProject: ProjectCardModel; actions: ReactNode }): ReactNode

// Fixtures the previews use (packages/ui/src/fixtures.ts) — also on the bundle global.
export const SAMPLE_METRICS: Metric[]
export const SAMPLE_PROJECTS: ProjectCardModel[]
export const SAMPLE_ARTICLES: ArticleCardModel[]
export const SAMPLE_CASE_STUDIES: CaseStudyModel[]
export const SAMPLE_FAQ: FaqItemModel[]
export const SAMPLE_SERVICES: ServiceModel[]
export const SAMPLE_RESOURCES: ResourceModel[]
export const SAMPLE_TESTIMONIALS: TestimonialModel[]
export const SAMPLE_RESUME: ResumeModel
export const SAMPLE_SITE_MAP: SiteMapSectionModel[]
