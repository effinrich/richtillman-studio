# Field
Label + control + error wrapper that wires the ids. Built from `packages/ui/src/field.tsx`; the preview runs the real component.

**Use it** around every Input, Textarea or Select in a form. The `ContactForm` composite is built from it.

**You provide:** `label`, `htmlFor` (= the control's `id`), the control as `children`, and `error` — pass the same string to the control so it sets `aria-invalid` and `aria-describedby="${id}-error"`.

**Tokens:** Label = type `label`, `color-muted-foreground`; error = `small` 400 in `color-destructive` with `role="alert"`, margin-top `space-1`. Vertical rhythm between Fields is `space-6` (`gap-6`).

**Do:** validate on submit and on blur; the error copy is a full sentence without a period ("Enter a valid email"). **Don't:** render Field without a control, or an error without also passing it to the control.
