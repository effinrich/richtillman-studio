# SiteMapCard
Compact link card for the Site Map page: title with an accent hover and a mono uppercase description. Built from `packages/ui/src/composites/site-map-card.tsx`.

**Use it** in accent-grouped grids on `/site-map` (`SAMPLE_SITE_MAP` sections: gold, cyan, magenta).

**You provide:** `link` — `{ title, description, href, accent: "gold" | "cyan" | "magenta" }`. The anchor gets `aria-label="{title}. {description}"`.

**Tokens:** GlassPanel `radius-2xl` `space-6`, full height in a grid; title 18px 600 `leading-tight` → hover the accent (`color-gold`/`color-cyan`/`color-magenta`); border hover accent/30; description `tag` mono uppercase `tracking-widest` muted.

**Do:** one accent per section, matching the section label. **Don't:** mix accents inside a grid.
