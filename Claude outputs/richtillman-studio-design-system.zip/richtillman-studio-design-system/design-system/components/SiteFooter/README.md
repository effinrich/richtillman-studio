# SiteFooter
Three-column footer: BrandMark + name + tagline, Explore (secondary nav), Connect (email, GitHub, LinkedIn icon buttons), then a copyright row with the stack line. Built from `packages/ui/src/layout/site-footer.tsx` + `layout/nav.ts`.

**Use it** through PortfolioLayout at the bottom of every route.

**You provide:** nothing — links come from `SECONDARY_NAV` and the hard-coded social hrefs (`hello@richtillman.dev`, github.com/effinrich, linkedin.com/in/richtillman).

**Tokens:** top border white/10, padding `space-16` vertical `space-6` horizontal, `max-w-7xl`, `gap-12` grid `md:grid-cols-3`; column labels `badge`-size mono uppercase muted; links 14px `text-white/60` → `color-gold`; icon buttons 40px `radius-lg` border white/10 → gold/30 + gold; bottom row 12px muted above a white/5 rule; stack line mono uppercase 0.2em: "React 19 · TanStack Start · Tailwind v4". Mark: `BrandMark` at 40px in `color-foreground`.

**Don't:** put primary nav here — Explore lists the secondary routes only.
