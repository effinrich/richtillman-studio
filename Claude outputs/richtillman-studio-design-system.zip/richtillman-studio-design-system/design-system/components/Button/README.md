# Button
Gold CTA and its five quieter variants; `ButtonAnchor` gives the same styling to a link. Built from `packages/ui/src/button.tsx` (CVA + Radix Slot); the preview runs the real component.

**Use it for** the one primary action on a view (`primary`/`gold`), secondary actions on glass (`glass`), a gold-outlined alternative (`outline`), inline text actions (`ghost`), and low-emphasis nav or external links (`muted`, the `ButtonAnchor` default).

**You provide:** `children` (a verb or destination, optional Lucide icon 16px `aria-hidden` after the text), `variant`, `fullWidth`, native button attributes. `type` defaults to `"button"`; pass `type="submit"` in forms. `asChild` renders the child element (a router link) with the classes instead of a `<button>`.

**Tokens:** fill `color-gold` → hover `#ffe54c`; label `color-primary-foreground`; `shadow-gold-glow` → `shadow-gold-glow-hover`; glass = `.glass-panel` + hover white/10; outline = border gold/30 + hover gold/10; ghost/muted text `color-gold` / `color-muted-foreground`. Radius `radius-sm` (ghost, muted: `radius-lg`). Padding `space-3` × `space-6`; min height `space-11`. Focus: `color-ring` 60% 2px with 2px black offset. Transition `duration-control`.

**Do:** one gold Button per section. Keep labels under four words. Use `fullWidth` for form submits on phones.
**Don't:** stack two gold Buttons. Put a Button inside a Chip or Badge. Remove the focus ring. Use `ghost` for anything that navigates away.
