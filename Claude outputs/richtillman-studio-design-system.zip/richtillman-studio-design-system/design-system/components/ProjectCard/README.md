# ProjectCard
Portfolio card with an image or kind icon, metric eyebrow, title, description and Tags; the kind (Project / Case Study / Article) is derived from the `href`. Built from `packages/ui/src/composites/project-card.tsx`; the preview uses `SAMPLE_PROJECTS`.

**Use it** in the Work grid and as the specimen on `/design-system`. External `http` hrefs open in a new tab.

**You provide:** `project` — `{ slug, title, description, tags[], href, metric?, image? }`. No image → a Lucide icon by kind (Box, BarChart3, FileText) at 48px white/30, gold on hover.

**Tokens:** `.glass-panel` `radius-2xl` clipped; media area 192px tall on a white/5 → transparent gradient; kind Tag top-right (`space-4` inset); body `space-6`; metric = `tag`-size mono uppercase `tracking-widest` in `color-gold`; title 20px 700 `tracking-tight`; description 14px muted; Tags `gap-2`. Hover: `-translate-y-2 scale-[1.02]`, border gold/40, gold glow, image `scale-105`, all at 500ms.

**Do:** give every project a `metric` — the card reads unbalanced without it. **Don't:** exceed 4 tags.
