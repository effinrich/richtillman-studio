# Separator
1px white/10 rule, horizontal `<hr>` or vertical aria-hidden div. Built from `packages/ui/src/separator.tsx`; the preview runs the real component.

**Use it** between list rows inside a GlassPanel (`divide-y divide-white/10` is the same value) and between inline groups in the footer.

**You provide:** `orientation` (`horizontal` default), `className` for margins; vertical needs a parent with a height.

**Tokens:** `color-border` at 10% (white/10).

**Don't:** use a Separator where whitespace (`space-6`+) already separates.
