# TokenSwatch
Click-to-copy color swatch: 80px color field, mono name, value (flips to "Copied" for 1.6s), usage note. Built from `packages/ui/src/composites/token-swatch.tsx`.

**Use it** on `/design-system` for the Brand and Surface token grids; also fine for any palette documentation.

**You provide:** `token` — `{ name, cssVar, value, usage }`; `value` must be a CSS color string (it is set as the field's `background`). Copies `value` to the clipboard (needs a secure context; the catch path just leaves "Copied" off).

**Tokens:** GlassPanel `radius-2xl` clipped; field border-bottom white/10; name 14px mono `color-foreground`; value `meta` mono muted; usage 12px muted; focus ring `color-ring` 60% inset.

**Do:** keep `usage` to one sentence. **Don't:** pass `var(--x)` as the value — copy would hand the consumer an unresolved reference.
