# ArticleDetailScreen
One article: back link, category Badge + date · read time, title, and the body paragraphs in a GlassPanel. Built from `packages/ui/src/screens/article-detail-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `article: ArticleCardModel` with `content: string[]` (each string is a paragraph) and optional `backHref` (default `/insights`).

**Tokens:** back link `label`-size mono uppercase muted with a 16px ArrowLeft; title `section` style; body `body-lg` in `text-white/70` on `.glass-panel`. `activeItem="insights"`.
