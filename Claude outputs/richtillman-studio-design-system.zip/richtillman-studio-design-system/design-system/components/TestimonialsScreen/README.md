# TestimonialsScreen
Quotes grid with a gold Quote glyph, the quote in `body-lg`, and author · role · company in mono. Built from `packages/ui/src/screens/testimonials-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `testimonials: TestimonialModel[]`. The app's seed list is currently empty; the preview uses the one `SAMPLE_TESTIMONIALS` entry. With an empty array the screen renders header only — add an empty state before shipping real data.

**Tokens:** Quote icon 32px `color-gold` at 40% opacity; grid `md:grid-cols-2` `gap-6`. `activeItem="testimonials"`.
