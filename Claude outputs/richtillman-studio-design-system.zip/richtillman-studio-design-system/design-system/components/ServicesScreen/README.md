# ServicesScreen
Services grid: one GlassPanel per service with a Lucide icon in gold, title and description. Built from `packages/ui/src/screens/services-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `services: ServiceModel[]` with `icon` one of `layers`, `git-branch`, `cpu`, `zap`, `users` (mapped to Lucide inside the screen; unknown falls back to Layers).

**Tokens:** icon 24px `color-gold` in a 48px `radius-lg` white/5 box; grid `md:grid-cols-2 lg:grid-cols-3` `gap-6`. `activeItem="services"`.
