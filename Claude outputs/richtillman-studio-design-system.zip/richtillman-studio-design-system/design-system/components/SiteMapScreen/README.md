# SiteMapScreen
Site map: sections with an accent-coloured rule under the label and a SiteMapCard grid per section. Built from `packages/ui/src/screens/site-map-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `sections: SiteMapSectionModel[]` (`{ id, label, accent, links[] }`); each link inherits the section accent.

**Tokens:** section label `eyebrow` mono with an `after:` 48px rule in `bg-gold` / `bg-cyan` / `bg-magenta`; grid `md:grid-cols-2 lg:grid-cols-3`. `activeItem="home"`.
