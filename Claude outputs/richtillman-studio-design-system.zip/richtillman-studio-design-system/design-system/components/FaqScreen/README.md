# FaqScreen
Accordion FAQ: each item a GlassPanel button with the question, a ChevronDown that rotates, and the answer revealed below. One open at a time. Built from `packages/ui/src/screens/faq-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `items: FaqItemModel[]` (`{ id, question, answer }`).

**Tokens:** question 18px 600 `color-foreground`; answer `body` `text-white/60`; chevron 20px muted, `rotate-180` open, `duration-control`; `aria-expanded` + `aria-controls` wired per item. `activeItem="faq"`.
