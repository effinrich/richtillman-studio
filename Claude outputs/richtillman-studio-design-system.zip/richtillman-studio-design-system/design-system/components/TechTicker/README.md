# TechTicker
Infinite horizontal marquee of stack names in mono caps, separated by white/10 slashes; the row is rendered twice and scrolled −50% over 30s. Built from `packages/ui/src/layout/tech-ticker.tsx`.

**Use it** via `PortfolioLayout showTicker` on Home only. Items are fixed in the component (Next.js … Figma MCP).

**You provide:** nothing — no props.

**Tokens:** `.animate-ticker` (`duration-ticker` 30s linear infinite; `animation: none` under reduced motion and in Storybook); top border white/5, `bg-black/50`, `backdrop-blur-sm`, padding `space-4`; text `label`-size mono uppercase `tracking-widest` muted; `gap-12`; `pointer-events-none`.

**Don't:** put links inside — it is decorative and non-interactive by design.
