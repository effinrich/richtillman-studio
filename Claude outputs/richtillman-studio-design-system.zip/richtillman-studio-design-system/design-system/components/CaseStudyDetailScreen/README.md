# CaseStudyDetailScreen
One case study: back link, Tags, title, subtitle, metric tiles, labelled sections ("Role", "Architecture", …), optional live link, and related studies. Built from `packages/ui/src/screens/case-study-detail-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box. The preview seeds the Nx Monorepo study with the app's real `DETAIL_CONTENT` sections.

**You provide:** `caseStudy: CaseStudyModel`, `sections: CaseStudySection[]` (`{ label, body }`), `related: CaseStudyModel[]`, optional `backHref` (default `/case-studies`). `liveHref` on the model adds an external ButtonAnchor with ArrowUpRight.

**Tokens:** section labels in `eyebrow` style `color-gold`; body `body-lg` `text-white/70`; metric tiles GlassPanel `radius-2xl` centred. `activeItem="case-studies"`.
