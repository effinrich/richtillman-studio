# Textarea
Glass multi-line input with resize disabled. Built from `packages/ui/src/textarea.tsx`; the preview runs the real component.

**Use it** for the contact message and any free text; default `rows` in the site is 4–5.

**You provide:** `id`, `name`, `rows`, `placeholder`, `error`, native textarea attributes.

**Tokens:** identical to Input (`.glass-input`, `color-input`, `color-border-glass`, `shadow-input-focus`, `space-11`, `radius-sm`) plus `resize: none`.

**Do:** set `rows` so the empty control shows its size. **Don't:** re-enable resize; the glass border does not stretch well.
