# BrandMark
The studio mark as a React component: JetBrains Mono braces in `currentColor` joined by a `color-gold` span with a `color-magenta` node, optional black tile. Built from `packages/ui/src/brand-mark.tsx`; the SVG is the same geometry as `assets/Logos/rt-mark-notile.svg`.

**Use it** wherever the site shows its own identity: NavigationBar (32px), SiteFooter (40px), an About or 404 page. For the app icon and social tiles use the exported PNGs in Logos, not this component.

**You provide:** `className` with a size and an ink (`h-8 w-8 text-white`); `tile` for the rounded black tile form; any SVG attribute. It is `aria-hidden` by default because it sits beside the name — pass `aria-hidden={false}`, `role="img"` and `aria-label="Rich Tillman Studio"` when it stands alone.

**Tokens:** braces `color-foreground` via `currentColor`; span 36×8 `fill-gold` with `radius-sm`; node r4 `fill-magenta` on a r6 `fill-black` keyline; tile `radius-2xl`-equivalent 24/128 with a `currentColor` 8% hairline (`color-border-glass`). Minimum 24px; below that use the wordmark.

**Do:** keep the mark in the mono-caps meta zone of a layout, not in body copy. **Don't:** recolor the braces (only the ink token changes), stretch, or add a glow beyond `shadow-gold-glow`.
