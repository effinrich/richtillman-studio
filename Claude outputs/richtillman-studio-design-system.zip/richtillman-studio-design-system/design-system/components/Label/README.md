# Label
Mono, uppercase, tracked form label in white/50. Built from `packages/ui/src/label.tsx`; the preview runs the real component.

**Use it** above every Input, Textarea and Select — through `Field`, which supplies it, or standalone for custom controls.

**You provide:** `htmlFor` matching the control `id`, `children`, label attributes.

**Tokens:** type `label` (12px mono, 0.1em, uppercase); `color-muted-foreground`; margin-bottom `space-2`.

**Do:** keep to one or two words. **Don't:** hide the label visually; placeholders are not labels here.
