# ResourcesScreen
Stack / resources list grouped by category: each entry a GlassPanel link with title, description and an ExternalLink glyph. Built from `packages/ui/src/screens/resources-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `resources: ResourceModel[]` (`{ id, title, description, category, href }`); categories are derived from the data and rendered as `eyebrow` headings.

**Tokens:** category eyebrows `color-gold`; panels `radius-2xl` `space-6`, hover border gold/30 and title → gold. `activeItem="stack"`.
