# Tag
The smallest label: 10px mono in white/50 inside a hairline border. Built from `packages/ui/src/tag.tsx`; the preview runs the real component.

**Use it for** technology names on ProjectCard and CaseStudy cards, resume skills, any dense list of nouns that must not compete with the card title.

**You provide:** `children` (one word or acronym), span attributes.

**Tokens:** type `tag`; border `color-border` (white/10); text `color-muted-foreground`; padding `space-0.5` × `space-2`; radius `radius-sm`.

**Do:** wrap Tags in a `flex-wrap` row with `gap-2`. Sentence case.
**Don't:** color a Tag (use Badge). Make it interactive.
