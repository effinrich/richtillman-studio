# CanvasBackground
Fixed full-viewport backdrop: 40px hairline grid, a top-to-bottom black scrim, and a WebGL "tubes cursor" (threejs-components 0.0.19 from jsDelivr, loaded at runtime) in gold/cyan/magenta; clicking empty space re-randomizes the colors. Built from `packages/ui/src/layout/canvas-background.tsx`.

**Use it** through PortfolioLayout (it picks `recessed` for the design-system route, `ambient` elsewhere). The preview constrains it to a 320px box with `className="absolute"`.

**You provide:** `intensity?: "ambient" | "recessed"` (canvas opacity 0.32 / 0.25 and a lighter / darker scrim), `className?`. Under `prefers-reduced-motion` the canvas is not mounted at all; if the CDN or WebGL fails it degrades to grid + scrim silently.

**Tokens:** tube colors `color-cyan`, `color-magenta`, `color-gold` (light colors add `#83f36e` and `#ff008a`, literals); grid lines white/3 at 40px; scrim `from-black/55 via-black/70 to-black/92` (ambient) or `/68 /80 /94` (recessed); `cursor-crosshair`.

**Don't:** stack anything non-`relative z-10` above it — the layout sets that for you.
