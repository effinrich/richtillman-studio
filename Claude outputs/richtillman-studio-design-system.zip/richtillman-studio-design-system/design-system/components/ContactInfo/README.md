# ContactInfo
Three stacked glass panels: email (gold Mail icon), location (cyan MapPin), and an availability panel with the status Chip. Built from `packages/ui/src/composites/contact-info.tsx`.

**Use it** on `/contact` as the `lg:col-span-2` sidebar. Content is hard-coded in the component: `hello@richtillman.dev`, "Remote · US Eastern Time", the 3–6 month engagement line.

**You provide:** nothing — no props. Edit the source to change copy.

**Tokens:** GlassPanel `radius-2xl` `space-6`, `space-y-6` between; icons 20px `color-gold` / `color-cyan`; headings 16px 700; body `text-white/60`; the mail link goes `color-gold` on hover; Chip `status` with `dot pulse`.

**Do:** keep the three-panel order. **Don't:** add social links here; they live in SiteFooter.
