# CaseStudiesScreen
Case-study index: one wide GlassPanel per study with Tags, title, subtitle, summary, metric pairs, and a CTA slot. Built from `packages/ui/src/screens/case-studies-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `caseStudies: CaseStudyModel[]` and `renderCta: (study) => ReactNode` (ghost "Read case study" → `study.href` in the app).

**Tokens:** panel `radius-2xl` `space-8`, hover border gold/30; metrics `metric`-style numerals in `color-gold` over `label` captions. `activeItem="case-studies"`.
