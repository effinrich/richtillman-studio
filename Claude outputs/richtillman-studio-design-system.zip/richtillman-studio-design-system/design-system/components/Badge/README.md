# Badge
Category marker in mono caps with a tinted fill and matching border. Built from `packages/ui/src/badge.tsx`; the preview runs the real component.

**Use it for** article categories, project tags with meaning ("Featured", "Performance"), and status words that are not interactive. Not clickable.

**You provide:** `children` (short noun phrase; CSS uppercases it), `variant` — `gold`, `cyan`, `magenta`, or `neutral` (default).

**Tokens:** type `badge` (10px mono 700, 0.2em); fill hue/10, border hue/30, text the hue (`color-gold`, `color-cyan`, `color-magenta`); neutral is white/5, white/10, white/70. Padding `space-1` × `space-3`; radius `radius-sm`; icon gap `space-2`.

**Do:** pair a color with a word — cyan and magenta must never be the only difference. Keep one Badge color per meaning across the site.
**Don't:** use a Badge as a button or filter (that is a Chip). Exceed ~5 words.
