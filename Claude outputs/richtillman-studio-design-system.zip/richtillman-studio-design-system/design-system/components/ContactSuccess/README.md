# ContactSuccess
Green confirmation banner shown after a successful submit: CheckCircle icon and "Message sent! I'll get back to you within 48 hours." Built from `packages/ui/src/composites/contact-success.tsx`.

**Use it** above ContactForm once `onSubmitted` fires; unmount it on the next edit.

**You provide:** nothing — no props.

**Tokens:** `color-success` (#4ade80) for the icon and the tints — border success/30, fill success/10 — and `color-success-foreground` (#86efac) for the 14px text (11:1 on the tinted black); `radius-xl` (0.75rem), padding `space-4` × `space-6`, gap `space-3`. These two tokens exist for this banner alone; reuse them for any future success state rather than adding greens.

**Don't:** reuse it for anything but the contact confirmation.
