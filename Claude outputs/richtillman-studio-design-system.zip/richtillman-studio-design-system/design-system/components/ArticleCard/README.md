# ArticleCard
Glass card linking to an Insights article: gold category Badge, date · read time, title, excerpt. Built from `packages/ui/src/composites/article-card.tsx`; the preview runs the real component with `SAMPLE_ARTICLES` fixtures.

**Use it** in the Insights grid and the "latest writing" strip on Home. One card per `ArticleCardModel`.

**You provide:** `article` — `{ slug, title, excerpt, category, publishedAt, readTime, href, featured?, content? }`. Renders as an `<a href>` (plain anchor; wrap or swap for the router link in the app).

**Tokens:** `.glass-panel` + `radius-2xl` + `space-6` padding; Badge `gold`; meta in `tag` mono at `color-muted-foreground` with a 4px white/20 dot; title 20px 700 `color-foreground` → hover `color-gold`; excerpt 14px `leading-relaxed` muted. Hover: border gold/30 + `shadow-glass-hover`-style gold glow.

**Do:** keep excerpts to two lines. **Don't:** add an image slot — that is ProjectCard's job.
