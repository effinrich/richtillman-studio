# InsightsScreen
Writing index: the featured article as a wide GlassPanel with a gold Badge and CTA, then an ArticleCard grid of the rest. Built from `packages/ui/src/screens/insights-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `articles: ArticleCardModel[]` (the one with `featured: true` takes the panel; the preview uses `SAMPLE_ARTICLES`) and `featuredCta: ReactNode` (primary "Read article" → the featured href).

**Tokens:** featured panel `radius-2xl` `space-8`; title 30px 700; grid `md:grid-cols-2 lg:grid-cols-3`. `activeItem="insights"`.
