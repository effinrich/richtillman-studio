# DesignSystemScreen
The `/design-system` route: SectionHeader, InPageTabs (Color · Type · Effects · Primitives · Composites), TokenSwatch grids from `design-tokens.ts`, type specimens, effect panels, live primitive specimens, and composite specimens. Built from `packages/ui/src/screens/design-system-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box. The canvas runs `recessed`.

**You provide:** `specimenProject: ProjectCardModel` (the ProjectCard specimen) and `actions: ReactNode` (primary "See selected work").

**Tokens:** the screen reads `BRAND_TOKENS`, `SURFACE_TOKENS`, `TYPE_SPECIMENS` from `screens/design-tokens.ts` — keep that file and this system's `tokens.json` in step; sections use `scroll-mt-[var(--ds-scroll-margin)]`. `activeItem="design-system"`.
