# Select
Native `<select>` in the glass input skin. Built from `Select` in `packages/ui/src/field.tsx`; the preview runs the real component.

**Use it** for a short fixed list (project type). Options are native; the dropdown is the browser's.

**You provide:** `id`, `name`, `defaultValue`/`value`, `<option>` children, `error`, native select attributes.

**Tokens:** same as Input (`.glass-input`, `color-input`, `color-border-glass`, `shadow-input-focus`, `space-11`, `radius-sm`).

**Do:** keep to ≤ 6 options; otherwise use Chips as filters. **Don't:** add a custom chevron; the source has none.
