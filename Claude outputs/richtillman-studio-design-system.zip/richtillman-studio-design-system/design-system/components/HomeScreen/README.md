# HomeScreen
The landing page: availability Chips, the `hero` headline "Building the bridge between design systems and AI-native developer tooling", two CTAs, three metric panels, and a vertical "click bg to randomize" hint for the canvas. Built from `packages/ui/src/screens/home-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `metrics: readonly Metric[]` (`{ value, label }`, the site shows three: "6,200+ npm installs · ForgeKit MCP", "200+ component design system", "500K+ users on shipped RN apps") and `actions: ReactNode` (the app passes two `ButtonLink`s: primary "See selected work" → /work, glass "Get in touch" → /contact, both `fullWidth`). Renders with `showTicker`.

**Tokens:** `hero` display style with one `.neon-text` word; Chips `default` with a `dot pulse` on "Remote"; metrics in `metric` style `color-gold` over `label`-size muted captions inside GlassPanels; `.stagger-1..6` entrance on each block.

**Don't:** add a third CTA, or move the neon word — one per headline.
