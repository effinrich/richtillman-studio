# WorkScreen
Selected work: SectionHeader "Portfolio projects" and a responsive ProjectCard grid with a closing CTA. Built from `packages/ui/src/screens/work-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `projects: ProjectCardModel[]` (the app loads Supabase with seed fallback; the preview uses `SAMPLE_PROJECTS`) and `discussCta: ReactNode` (primary "Discuss a project" → /contact).

**Tokens:** grid `gap-6` at `md:grid-cols-2 lg:grid-cols-3`; cards carry their own `.stagger-*`. `activeItem="work"`.
