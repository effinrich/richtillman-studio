# Chip
44px glass chip for stack items and an "Available" status variant for the header. Built from `packages/ui/src/chip.tsx`; the preview runs the real component.

**Use it for** tech-stack lists (`default`), remote/availability signals with a gold dot, and the status pill in the fixed NavigationBar (`status`).

**You provide:** `children`, `variant` (`default` | `status`), `dot`, `pulse`, span attributes.

**Tokens:** default = `.glass-panel` (`color-glass`, `color-border-glass`, `shadow-glass`), mono `xs` text white/70, hover white/5. Status = border gold/30, fill gold/5, `xs` 500 in `color-gold`, and no `backdrop-filter` (blur in the fixed header composites into a full-viewport overlay while scrolling). Dot `color-gold`, 6px / 8px on status, `radius-full`. Padding `space-1.5` × `space-3`; min height `space-11`.

**Do:** use `pulse` only with `dot`; it stops under reduced motion. Keep chip text to two or three words.
**Don't:** blur a status chip. Put a status chip anywhere but the header or hero.
