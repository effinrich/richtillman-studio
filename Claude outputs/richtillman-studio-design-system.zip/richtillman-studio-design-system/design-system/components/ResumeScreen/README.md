# ResumeScreen
Résumé page: summary, PDF download CTA, experience timeline with highlights, projects, and a Chip cloud of skills. Built from `packages/ui/src/screens/resume-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `resume: ResumeModel` (`summary`, `experience[]`, `projects[]`, `skills[]`) and optional `pdfHref` (default `/resume/rich-tillman.pdf`, which the repo commits under `apps/web/public/resume/`).

**Tokens:** download is `ButtonAnchor primary` with a 16px Download icon; period lines in `label` mono muted; skills as default Chips `gap-2`. `activeItem="resume"`.
