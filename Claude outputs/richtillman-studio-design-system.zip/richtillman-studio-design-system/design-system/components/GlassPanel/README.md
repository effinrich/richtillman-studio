# GlassPanel
The raised surface: `.glass-panel` on a div. Built from `packages/ui/src/glass-panel.tsx`; the preview runs the real component.

**Use it** for cards, specimen boxes, the nav bar, and any content that sits above the canvas background. Add `neon-border-gold|cyan|magenta` to single one panel out.

**You provide:** `children` and `className` — the panel has no radius or padding of its own; the site uses `rounded-2xl p-6 md:p-8`, and hover glow when it is a link (`hover:border-gold/40 hover:shadow-[0_0_20px_rgba(255,215,0,0.1)]`).

**Tokens:** fill `color-glass`, 16px backdrop blur, border `color-border-glass`, `shadow-glass`; rails 4px in `color-gold`/`color-cyan`/`color-magenta` with `shadow-rail-*`; radius `radius-2xl`; padding `space-6` / `space-8`.

**Do:** nest text tokens unchanged; contrast on glass holds. **Don't:** stack panels inside panels, or use a rail color that has no meaning in the group.
