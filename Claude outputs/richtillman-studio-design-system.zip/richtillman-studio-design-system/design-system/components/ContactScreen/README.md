# ContactScreen
Contact page: SectionHeader, then a 5-column grid — ContactForm (3) and ContactInfo (2) — with ContactSuccess shown above the form after a successful submit (local state). Built from `packages/ui/src/screens/contact-screen.tsx`. Every screen is a full page inside `PortfolioLayout` (canvas, nav, footer) with a `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24` container; the app route is a thin wrapper that loads data and passes router-aware CTAs as `ReactNode`. The preview scrolls inside a 720px box.

**You provide:** `onSubmit: ContactSubmitHandler` (the app posts to Supabase; the preview resolves after 800ms — submit the form to see the success banner).

**Tokens:** grid `gap-12 lg:grid-cols-5`; everything else from the three composites. `activeItem="contact"`.
