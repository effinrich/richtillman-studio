# SectionHeader
Eyebrow rule, display title, lead paragraph — the top of every page and section. Built from `packages/ui/src/section-header.tsx`; the preview runs the real component.

**Use it** once per page as `h1`, and as `h2` (`headingLevel`) for in-page sections.

**You provide:** `title` (ReactNode; one word may be wrapped in `<span class="neon-text">`), optional `eyebrow`, optional `description`, `headingLevel`, `className` (the design-system page passes `mb-0` inside specimens).

**Tokens:** eyebrow = 48px × 1px rule at gold/40 + type `eyebrow` in `color-gold`, gap `space-3`, margin-bottom `space-6`; title = type `section` (Inter 700, 48→72px, −0.05em), margin-bottom `space-8`; description = `body-lg` at `color-muted-foreground`, `max-w-2xl`; block margin-bottom `space-16` / `space-24`.

**Do:** keep the neon word to one. **Don't:** put a Button inside; actions go after the header.
