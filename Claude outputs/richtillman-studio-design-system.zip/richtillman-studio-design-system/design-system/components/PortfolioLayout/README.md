# PortfolioLayout
The page shell every route renders in: CanvasBackground behind, then NavigationBar, the page (`flex-1`), optional TechTicker, and SiteFooter in a `relative z-10` column. Built from `packages/ui/src/layout/portfolio-layout.tsx`.

**Use it** as the outermost element of every screen; screens then use `main.mx-auto.max-w-7xl.px-6.pt-32.pb-24`.

**You provide:** `children`, `activeItem?: NavItem` (default "home"), `showTicker?: boolean` (default false; Home sets it).

**Tokens:** everything from its parts; the canvas is `recessed` when `activeItem === "design-system"`, `ambient` otherwise. `min-h-screen` on both wrapper and column so short pages still push the footer down.

**Don't:** nest it, or add a second fixed element at the top — the nav owns `top-0 z-40`.
