# ContactForm
The contact page form: Name + Email side by side, Company, Project type Select, Message, gold submit; validates on blur and submit. Built from `packages/ui/src/composites/contact-form.tsx` + `contact-validation.ts`; the preview's `onSubmit` resolves after 800ms.

**Use it** on `/contact` beside ContactInfo (`lg:col-span-3` of a 5-column grid). Show ContactSuccess via `onSubmitted`.

**You provide:** `onSubmit: (input: ContactSubmitInput) => Promise<unknown>` (throwing sets a `color-destructive` error line under the form) and optional `onSubmitted()`. Project types are fixed in the component: Design System, Nx Monorepo, MCP / AI Tooling, Frontend Platform, Advisory, Other.

**Tokens:** Field rhythm `space-6` (`space-y-6`); the two-up row is `sm:grid-cols-2`; submit is `Button primary fullWidth`, disabled while pending with the label "Sending...". Errors: "Name is required", "Email is required", "Enter a valid email", "Message is required".

**Do:** keep the error copy as written — the tests assert it. **Don't:** add a honeypot or captcha inside; wrap it outside.
