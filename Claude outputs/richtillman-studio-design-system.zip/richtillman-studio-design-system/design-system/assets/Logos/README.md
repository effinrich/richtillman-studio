The brand mark — "Brace". Drawn for the system from its own tokens (the repo had no logo; its `logo*.png` are React's defaults), now committed at `apps/web/public/brand/` and rendered in code by the `BrandMark` component in the header and footer.

The idea: two JetBrains Mono braces `{ }` with a gold span between them and a magenta node at the join — the bridge between design systems and code, in the system's own meta face. Chosen over a literal bridge (the earlier "Span") because it holds at 20px and says what the studio does.

- `rt-mark.svg` — the app icon: black tile (`radius-2xl` at 24/128), hairline `color-border-glass` edge, braces in `color-foreground`, span `color-gold` (36×8, `radius-sm`), node `color-magenta` r4 with a 2px black keyline. Use at 24px and up; favicon, avatar, social tile. Below 24px the braces thin out — use `rt-mark-32.png`/`-16` sparingly and prefer the wordmark.
- `rt-mark-notile.svg` — same mark without the tile, for any black or glass surface (nav bar, footer, cover).
- `rt-mark-mono.svg` — single-ink version, ink `#ffffff` (`color-foreground`); the node becomes a gap in the span. `<img>` cannot recolor it: for black-on-white, invert or edit the fill.
- `rt-wordmark.svg` — "Rich Tillman Studio" set in Inter 800 at −0.05em (the `section` display style), outlined to paths; ink `color-foreground`.
- `rt-lockup.svg` — mark (no tile) + 16px gap + wordmark, 76px tall. Header and footer use. Minimum height 32px.
- `rt-mark-512.png`, `-192`, `-64`, `-32` — raster exports of the tile for the web manifest and favicons.

Rules: clear space around the lockup equals the span height (8/128 of the mark height). Never re-tint the braces or the span; on a light ground use the mono version in black. Do not stretch, outline, or add glow beyond `shadow-gold-glow`. The braces are glyphs from the system's mono face — do not swap the font.
